"""Tunable settings for the P2P node."""

HOST = "127.0.0.1"
MIN_PIECE_SIZE = 4 * 1024        # smallest piece
MAX_PIECE_SIZE = 256 * 1024      # largest piece
TARGET_PIECES = 128              # aim for about this many pieces per file
MAX_WORKERS = 4
SOCKET_TIMEOUT = 15
UPLOAD_DELAY = 0.05  # seconds every served piece is delayed (hardcoded demo throttle; set 0 to disable)
STALL_TIMEOUT = 20  # seconds without any verified piece before a download gives up
